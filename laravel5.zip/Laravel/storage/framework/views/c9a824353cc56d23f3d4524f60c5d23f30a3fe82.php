<div <?php echo e($attributes->merge(['class' => 'bg-gray-50 border border-gray-200 rounded p-6'])); ?>>
  <?php echo e($slot); ?>

</div><?php /**PATH /home/rafael/Imagens/laragigs-main/resources/views/components/card.blade.php ENDPATH**/ ?>